{
    "version": "1.7",
    "octreeDir": "data",
    "projection": "",
    "points": 4576369,
    "boundingBox": {
        "lx": 771484.391,
        "ly": 3308257.773,
        "lz": -354.34100341796877,
        "ux": 778563.0129999999,
        "uy": 3315336.395,
        "uz": 6724.280996582005
    },
    "tightBoundingBox": {
        "lx": 771484.3910000001,
        "ly": 3308257.773,
        "lz": -354.34100341796877,
        "ux": 777692.212,
        "uy": 3315336.3949999997,
        "uz": 425.76800537109377
    },
    "pointAttributes": [
        "POSITION_CARTESIAN",
        "COLOR_PACKED"
    ],
    "spacing": 61.30266571044922,
    "scale": 0.001,
    "hierarchyStepSize": 5
}